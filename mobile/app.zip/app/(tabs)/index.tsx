import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';

const categories = [
  { name: 'Fresh Food', icon: require('../../assets/icons/fresh_food.png') },
  { name: 'Bakery', icon: require('../../assets/icons/bakery.png') },
  { name: 'Treats & Snacks', icon: require('../../assets/icons/snacks.png') },
  { name: 'Food Cupboard', icon: require('../../assets/icons/food_cupboard.png') },
  { name: 'Frozen Food', icon: require('../../assets/icons/frozen_food.png') },
  { name: 'Drinks', icon: require('../../assets/icons/drinks.png') },
  { name: 'Baby', icon: require('../../assets/icons/baby.png') },
  { name: 'Health & Beauty', icon: require('../../assets/icons/health_beauty.png') },
  { name: 'Pets', icon: require('../../assets/icons/pets.png') },
  { name: 'Household', icon: require('../../assets/icons/household.png') },
  { name: 'Home & Living', icon: require('../../assets/icons/home_living.png') },
  { name: 'Inspiration & Events', icon: require('../../assets/icons/events.png') },
];


const sampleBasket = [
  { id: 1, name: 'Leche Entera (1L)', quantity: '1 unidad' },
  { id: 2, name: 'Pan de Molde', quantity: '1 unidad' },
  { id: 3, name: 'Huevos (12 unidades)', quantity: '1 paquete' },
];

export default function HomeScreen() {
  const [searchText, setSearchText] = useState('');

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>MasterMarket</Text>

      {/* Search Bar */}
      <TextInput
        style={styles.searchInput}
        placeholder="Search product: e.g. milk, bread..."
        value={searchText}
        onChangeText={setSearchText}
      />

		{/* Categories */}
		<Text style={styles.sectionTitle}>Browse by Category</Text>
		<ScrollView horizontal showsHorizontalScrollIndicator={false}>
		  <View style={styles.categoriesWrapper}>
			{categories.map((category) => (
			  <TouchableOpacity key={category.name} style={styles.categoryItem}>
				<Image source={category.icon} style={styles.categoryIcon} />
				<Text style={styles.categoryText}>{category.name}</Text>
			  </TouchableOpacity>
			))}
		  </View>
		</ScrollView>

      {/* Basket */}
      <Text style={styles.sectionTitle}>My Basket</Text>
      <View style={styles.basketContainer}>
        {sampleBasket.map((item) => (
          <View key={item.id} style={styles.basketItem}>
            <Text style={styles.basketText}>{item.name}</Text>
            <Text style={styles.basketQuantity}>{item.quantity}</Text>
            <TouchableOpacity>
              <Text style={styles.removeButton}>✕</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>

      {/* Action Buttons */}
      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.compareButton}>
          <Text style={styles.buttonText}>Compare Prices</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.matchButton}>
          <Text style={styles.buttonText}>Mix & Match</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#F9F9F9',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
    color: '#5A31F4',
  },
  searchInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    borderColor: '#DDD',
    borderWidth: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 12,
  },
  categoriesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
 categoriesWrapper: {
  flexDirection: 'row',
  flexWrap: 'wrap',
  rowGap: 12,
  columnGap: 16,
  paddingBottom: 12,
  maxHeight: 150, // controla las dos filas
},
categoryItem: {
  width: 80,
  alignItems: 'center',
  marginRight: 12,
},
categoryIcon: {
  width: 50,
  height: 50,
  marginBottom: 4,
},
  categoryText: {
    fontSize: 12,
    textAlign: 'center',
  },
  basketContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
    borderColor: '#DDD',
    borderWidth: 1,
  },
  basketItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  basketText: {
    flex: 1,
    fontSize: 14,
  },
  basketQuantity: {
    fontSize: 14,
    color: '#666',
    marginRight: 8,
  },
  removeButton: {
    fontSize: 18,
    color: 'red',
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  compareButton: {
    backgroundColor: '#00B894',
    flex: 1,
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  matchButton: {
    backgroundColor: '#A29BFE',
    flex: 1,
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 16,
  },
});
