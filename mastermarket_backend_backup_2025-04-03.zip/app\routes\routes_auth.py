from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests
from app.auth import create_access_token  # usamos tu función ya existente
from fastapi import Depends
from app.auth import get_current_user
from app import models

router = APIRouter()

GOOGLE_TOKEN_INFO_URL = "https://oauth2.googleapis.com/tokeninfo"

class GoogleToken(BaseModel):
    id_token: str

@router.post("/google-login")
def google_login(data: GoogleToken):
    response = requests.get(GOOGLE_TOKEN_INFO_URL, params={"id_token": data.id_token})
    
    if response.status_code != 200:
        raise HTTPException(status_code=401, detail="Token de Google inválido")

    user_info = response.json()
    email = user_info.get("email")
    name = user_info.get("name")

    if not email:
        raise HTTPException(status_code=400, detail="Email no encontrado en el token")

    # En este ejemplo usamos el email como "sub"
    jwt_token = create_access_token({"sub": email, "name": name})
    return {"access_token": jwt_token}

@router.get("/me")
def read_current_user(current_user: models.User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "name": current_user.name
    }
